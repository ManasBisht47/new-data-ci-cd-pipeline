"""Various constants."""

from __future__ import annotations

CLIENT_NAME = "AsyncioPythonConnector"  # don't change!
